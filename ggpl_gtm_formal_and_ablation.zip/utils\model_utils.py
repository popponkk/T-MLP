import os
import time
import json
import yaml
import shutil
import random
import datetime
from pathlib import Path

import numpy as np

from typing import Dict, List, Tuple, Union, Optional, Literal

import torch
import torch.nn as nn
import optuna

from models import (
    MLP, tMLP, TabMModel, TJEPABaseline, MoETMLP, FTTransformer, ExcelFormer, AutoInt, DCNv2, NODE,
    XGBoostModel, CatBoostModel, LightGBMModel, RealMLPBaseline,
    SRTMLP, SRPEETMLP, SRLGRTMLP, PRTMLP, HRETMLP, AGRTMLP, ADRTMLP, SGATMLPLite, AGSITMLP, SRAGRTMLPLite, AGRTMLPRex2Lite, AGRTMLPRex2GuardedLite, AGRTMLPSwitchLite, AGRTMLPSwitchLiteTD, AGRTMLPSwitchHardLite, CGRTMLP, CGRTMLPV2, LARTMLP, HLRTMLP, SCGRTMLP, CGRTMLPV3, CGRTMLPStage2, NRCGRTMLP, QCALCGRTMLP, GGPLCGRTMLP, RGCCGRTMLP, AGPLCGRTMLP, APARCGRTMLP, DPGCGRTMLP, GGTMTMLP, SGGCGRTMLP, IGGPLCGRTMLP, GGPLTabMCGR, ExcelCGRLite, LGBMCGRHybrid,
    GGPLTMLP, GGPLGTM, GGPLGTMAblation, GGPLGTMFullAblation, GGPLGTMNoChannelAblation, GGPLGTMNoGraphAblation, GGPLGTMNoGraphNoChannelAblation, GGPLGTMLinearAblation, GGPLGTMLinearNoChannelAblation, GGPLGTMLinearNoGraphAblation, GGPLGTMLinearNoGraphNoChannelAblation, GGPLTMLPLayerScale, GGPLTMLPSGURefine, GGPLTMLPTokChan, GGPLTMLPTokChanLite, GGPLTMLPBPFiLM, GGPLTMLPTokChanBPGate, GGPLTMLPSlimTok, GGPLTMLPFNetSlimTok, GGPLTMLPDLRSlimTok, GGPLTMLPOSCSlimTok, GGPLTMLPAnchorSlimTok, GGPLTMLPLIRSlimTok, GGPLTMLPGBASlimTok, GGPLTMLPAttnSlimTok, GGPLTMLPSSMSlimTok, GGPLTMLPTabMSlimTok, GGPLTMLPGraphSlimTok, GGPLTMLPGraphSlimTokNoGGPL, GGPLTMLPGraphSlimTokNoGraph, GGPLTMLPGraphSlimTokNoChannel, GGPLTMLPGraphSlimTokNoBlock, GGPLTMLPSwapGraphSlimTok, GGPLTMLPDualGraphSlimTok, GGPLTMLPAMixGraphSlimTok, GGPLTMLPSparseGraphSlimTok, GGPLTMLPGraphReadoutSlimTok, GGPLTMLPSafeGraphReadoutSlimTok, GGPLTMLPPMUGraphSlimTok, GraphSlimTokTMLP, GraphSlimTokTMLPDynamicOnly, GraphSlimTokTMLPIdentityStatic, GraphSlimTokTMLPNoBlock, GraphSlimTokTMLPNoChannel, GraphSlimTokTMLPNoGraph, GraphSlimTokTMLPStaticOnly, GraphSlimTokTMLPStaticPrior, GGPLTMLPCrossMix, GGPLTMLPSetMix, GGPLTMLPButterflyTok, GGPLTMLPMLPHead, GGPLTMLPGLUHead, GGPLTMLPGFG,
)
from models.abstract import TabModel, check_dir
from utils.data_utils import Dataset
from data.processor import DataProcessor

MODEL_CARDS = {
    'xgboost': XGBoostModel, 'catboost': CatBoostModel, 'lightgbm': LightGBMModel, 'realmlp': RealMLPBaseline,
    'mlp': MLP, 'tmlp': tMLP, 'tabm': TabMModel, 'tjepa': TJEPABaseline, 'autoint': AutoInt, 'dcnv2': DCNv2, 'node': NODE,
    'baseline_tmlp': tMLP,
    'ggpl_tmlp': GGPLTMLP,
    'ggpl_gtm': GGPLGTM,
    'ggpl_gtm_ablation': GGPLGTMAblation,
    'ggpl_gtm_ablation_full': GGPLGTMFullAblation,
    'ggpl_gtm_ablation_no_channel': GGPLGTMNoChannelAblation,
    'ggpl_gtm_ablation_no_graph': GGPLGTMNoGraphAblation,
    'ggpl_gtm_ablation_no_graph_no_channel': GGPLGTMNoGraphNoChannelAblation,
    'ggpl_gtm_ablation_linear': GGPLGTMLinearAblation,
    'ggpl_gtm_ablation_linear_no_channel': GGPLGTMLinearNoChannelAblation,
    'ggpl_gtm_ablation_linear_no_graph': GGPLGTMLinearNoGraphAblation,
    'ggpl_gtm_ablation_linear_no_graph_no_channel': GGPLGTMLinearNoGraphNoChannelAblation,
    'ggpl_tmlp_layerscale': GGPLTMLPLayerScale,
    'ggpl_tmlp_sgurefine': GGPLTMLPSGURefine,
    'ggpl_tmlp_tokchan': GGPLTMLPTokChan,
    'ggpl_tmlp_tokchan_lite': GGPLTMLPTokChanLite,
    'ggpl_tmlp_bpfilm': GGPLTMLPBPFiLM,
    'ggpl_tmlp_tokchan_bpgate': GGPLTMLPTokChanBPGate,
    'ggpl_tmlp_slimtok': GGPLTMLPSlimTok,
    'ggpl_tmlp_fnet_slimtok': GGPLTMLPFNetSlimTok,
    'ggpl_tmlp_dlr_slimtok': GGPLTMLPDLRSlimTok,
    'ggpl_tmlp_osc_slimtok': GGPLTMLPOSCSlimTok,
    'ggpl_tmlp_anchor_slimtok': GGPLTMLPAnchorSlimTok,
    'ggpl_tmlp_lir_slimtok': GGPLTMLPLIRSlimTok,
    'ggpl_tmlp_gba_slimtok': GGPLTMLPGBASlimTok,
    'ggpl_tmlp_attn_slimtok': GGPLTMLPAttnSlimTok,
    'ggpl_tmlp_ssm_slimtok': GGPLTMLPSSMSlimTok,
    'ggpl_tmlp_tabm_slimtok': GGPLTMLPTabMSlimTok,
    'ggpl_tmlp_graph_slimtok': GGPLTMLPGraphSlimTok,
    'ggpl_tmlp_graph_slimtok_no_ggpl': GGPLTMLPGraphSlimTokNoGGPL,
    'ggpl_tmlp_graph_slimtok_no_graph': GGPLTMLPGraphSlimTokNoGraph,
    'ggpl_tmlp_graph_slimtok_no_channel': GGPLTMLPGraphSlimTokNoChannel,
    'ggpl_tmlp_graph_slimtok_no_block': GGPLTMLPGraphSlimTokNoBlock,
    'ggpl_tmlp_swap_graph_slimtok': GGPLTMLPSwapGraphSlimTok,
    'ggpl_tmlp_dual_graph_slimtok': GGPLTMLPDualGraphSlimTok,
    'ggpl_tmlp_amix_graph_slimtok': GGPLTMLPAMixGraphSlimTok,
    'ggpl_tmlp_sparse_graph_slimtok': GGPLTMLPSparseGraphSlimTok,
    'ggpl_tmlp_graph_readout_slimtok': GGPLTMLPGraphReadoutSlimTok,
    'ggpl_tmlp_safe_graph_readout_slimtok': GGPLTMLPSafeGraphReadoutSlimTok,
    'ggpl_tmlp_pmu_graph_slimtok': GGPLTMLPPMUGraphSlimTok,
    'graph_slimtok_tmlp': GraphSlimTokTMLP,
    'graph_slimtok_tmlp_no_graph': GraphSlimTokTMLPNoGraph,
    'graph_slimtok_tmlp_no_channel': GraphSlimTokTMLPNoChannel,
    'graph_slimtok_tmlp_no_block': GraphSlimTokTMLPNoBlock,
    'graph_slimtok_tmlp_dynamic_only': GraphSlimTokTMLPDynamicOnly,
    'graph_slimtok_tmlp_static_only': GraphSlimTokTMLPStaticOnly,
    'graph_slimtok_tmlp_identity_static': GraphSlimTokTMLPIdentityStatic,
    'graph_slimtok_tmlp_static_prior': GraphSlimTokTMLPStaticPrior,
    'ggpl_tmlp_crossmix': GGPLTMLPCrossMix,
    'ggpl_tmlp_setmix': GGPLTMLPSetMix,
    'ggpl_tmlp_butterflytok': GGPLTMLPButterflyTok,
    'ggpl_tmlp_mlphead': GGPLTMLPMLPHead,
    'ggpl_tmlp_gluhead': GGPLTMLPGLUHead,
    'ggpl_tmlp_gfg': GGPLTMLPGFG,
    'cgr_tmlp': CGRTMLP,
    'cgr_tmlp_stage2': CGRTMLPStage2,
    'nr_cgr_tmlp': NRCGRTMLP,
    'qcal_cgr_tmlp': QCALCGRTMLP,
    'ggpl_cgr_tmlp': GGPLCGRTMLP,
    'rgc_cgr_tmlp': RGCCGRTMLP,
    'agpl_cgr_tmlp': AGPLCGRTMLP,
    'apar_cgr_tmlp': APARCGRTMLP,
    'dpg_cgr_tmlp': DPGCGRTMLP,
    'ggtm_tmlp': GGTMTMLP,
    'sgg_cgr_tmlp': SGGCGRTMLP,
    'iggpl_cgr_tmlp': IGGPLCGRTMLP,
    'ggpl_tabm_cgr': GGPLTabMCGR,
    'excel_cgr_lite': ExcelCGRLite,
    'lgbm_cgr_hybrid': LGBMCGRHybrid,
    'cgr_tmlp_v2': CGRTMLPV2,
    'cgr_tmlp_v3': CGRTMLPV3,
    'lar_tmlp': LARTMLP,
    'hlr_tmlp': HLRTMLP,
    'scgr_tmlp': SCGRTMLP,
    'agr_tmlp_switch_lite_td': AGRTMLPSwitchLiteTD,
    'agr_tmlp_switch_hardlite': AGRTMLPSwitchHardLite,
    'agr_tmlp_switch_lite': AGRTMLPSwitchLite,
    'agr_tmlp_rex2_guarded_lite': AGRTMLPRex2GuardedLite,
    'agr_tmlp_rex2_lite': AGRTMLPRex2Lite,
    'sr_agr_tmlp_lite': SRAGRTMLPLite,
    'agsi_tmlp': AGSITMLP,
    'sga_tmlp_lite': SGATMLPLite,
    'sga_tmlp_lite_no_beta_reg': SGATMLPLite,
    'sga_tmlp_lite_no_corr_reg': SGATMLPLite,
    'sga_tmlp_lite_no_featmix': SGATMLPLite,
    'sga_tmlp_lite_topk4': SGATMLPLite,
    'sga_tmlp_lite_topk12': SGATMLPLite,
    'adr_tmlp': ADRTMLP,
    'agr_tmlp': AGRTMLP,
    'agr_tmlp_no_err_head': AGRTMLP,
    'agr_tmlp_no_gate_reg': AGRTMLP,
    'agr_tmlp_no_res_reg': AGRTMLP,
    'agr_tmlp_gate_from_h_only': AGRTMLP,
    'agr_tmlp_softgate': AGRTMLP,
    'pr_tmlp_residual': PRTMLP,
    'pr_tmlp_residual_no_sparse': PRTMLP,
    'pr_tmlp_residual_no_balance': PRTMLP,
    'pr_tmlp_residual_no_sep': PRTMLP,
    'pr_tmlp_pure_experts': PRTMLP,
    'hre_tmlp': HRETMLP,
    'hre_tmlp_no_balance': HRETMLP,
    'hre_tmlp_no_div': HRETMLP,
    'hre_tmlp_no_alpha': HRETMLP,
    'hre_tmlp_no_global_residual': HRETMLP,
    'hre_tmlp_dense_routing': HRETMLP,
    'moe_tmlp': MoETMLP, 'moe_tmlp_no_sparse': MoETMLP, 'moe_tmlp_no_diversity': MoETMLP,
    'ft-transformer': FTTransformer, 'saint': None,
    'tmlp-sr': SRTMLP, 'tmlp-sr-pee': SRPEETMLP, 'tmlp-sr-lgr': SRLGRTMLP,
    't2g-former': None, 'excel-former': ExcelFormer,
}
HPOLib = Literal['optuna', 'hyperopt'] # TODO: add 'hyperopt' support

def get_model_cards():
    return {
        'available': sorted(list([key for key, value in MODEL_CARDS.items() if value])),
        'comming soon': sorted(list([key for key, value in MODEL_CARDS.items() if not value]))
    }

def seed_everything(seed=42):
    '''
    Sets the seed of the entire notebook so results are the same every time we run.
    This is for REPRODUCIBILITY.
    '''
    random.seed(seed)
    # Set a fixed value for the hash seed
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        # When running on the CuDNN backend, two further options must be set
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

def make_default_baseline(model_name):
    if model_name == 'xgboost':
        return XGBoostModel
    elif model_name == 'catboost':
        return CatBoostModel
    elif model_name == 'lightgbm':
        return LightGBMModel
    elif model_name == 'ft-transformer':
        pass
    elif model_name == 't2g-former':
        pass
    elif model_name == 'excel-former':
        pass
    else:
        assert model_name in MODEL_CARDS, f"unrecognized `{model_name}` model name, choose one of valid models in {MODEL_CARDS}"
        raise NotImplementedError(
            f"model `{model_name}` has no default configuration in previous works, \
            if you want to use in fixed settings, initialize with `make_baseline`."
        )

def load_config_from_file(file):
    file = str(file)
    if file.endswith('.yaml'):
        with open(file, 'r') as f:
            cfg = yaml.safe_load(f)
    elif file.endswith('.json'):
        with open(file, 'r') as f:
            cfg = json.load(f)
    else:
        raise AssertionError('Config files only support yaml or json format now.')
    return cfg

def extract_config(model_config: dict, is_large_data: bool = False):
    """selection of different search spaces"""
    used_cfgs = {"model": {}, "training": {}, 'meta': model_config.get('meta', {})}
    for field in ['model', 'training']:
        for k in model_config[field]:
            cfgs = model_config[field][k]
            if 'type2' not in cfgs:
                used_cfg = cfgs
            else:
                if not is_large_data:
                    used_cfg = {k: v for k, v in cfgs.items() if not k.endswith('2')}
                else:
                    used_cfg = {k[:-1]: v for k, v in cfgs.items() if k.endswith('2')}
            used_cfgs[field][k] = used_cfg
    return used_cfgs

def make_baseline(
    model_name, 
    model_config: Union[dict, str], 
    n_num: int, 
    cat_card: Optional[List[int]],
    n_labels: int,
    feat_gate: Optional[str] = None,
    pruning: Optional[str] = None,
    dataset: Optional[Dataset] = None,
    device: Union[str, torch.device] = 'cuda',
) -> TabModel:
    """Process Model Configs and Call Specific Model APIs"""
    assert model_name in MODEL_CARDS, f"unrecognized `{model_name}` model name, choose one of valid models in {MODEL_CARDS}"
    if isinstance(model_config, str):
        print('load from model config file: ', model_config)
        model_config = load_config_from_file(model_config)['model']
    if MODEL_CARDS[model_name] is None:
        raise NotImplementedError("Please add corresponding model implementation to `models` module")
    if model_name == 'tmlp':
        return tMLP(
            model_config=model_config, 
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset)
    if model_name.startswith('pr_tmlp'):
        return PRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
            variant_name=model_name,
        )
    if model_name == 'agr_tmlp_rex2_lite':
        return AGRTMLPRex2Lite(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'agr_tmlp_rex2_guarded_lite':
        return AGRTMLPRex2GuardedLite(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'agr_tmlp_switch_lite':
        return AGRTMLPSwitchLite(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'agr_tmlp_switch_lite_td':
        return AGRTMLPSwitchLiteTD(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'agr_tmlp_switch_hardlite':
        return AGRTMLPSwitchHardLite(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'cgr_tmlp':
        return CGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'cgr_tmlp_stage2':
        return CGRTMLPStage2(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'nr_cgr_tmlp':
        return NRCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'qcal_cgr_tmlp':
        return QCALCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'ggpl_cgr_tmlp':
        return GGPLCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'rgc_cgr_tmlp':
        return RGCCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'agpl_cgr_tmlp':
        return AGPLCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'apar_cgr_tmlp':
        return APARCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'dpg_cgr_tmlp':
        return DPGCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'ggtm_tmlp':
        return GGTMTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'sgg_cgr_tmlp':
        return SGGCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'iggpl_cgr_tmlp':
        return IGGPLCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'ggpl_tabm_cgr':
        return GGPLTabMCGR(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'excel_cgr_lite':
        return ExcelCGRLite(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'lgbm_cgr_hybrid':
        return LGBMCGRHybrid(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'cgr_tmlp_v2':
        return CGRTMLPV2(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'cgr_tmlp_v3':
        return CGRTMLPV3(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'lar_tmlp':
        return LARTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'hlr_tmlp':
        return HLRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'scgr_tmlp':
        return SCGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'sr_agr_tmlp_lite':
        return SRAGRTMLPLite(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name == 'agsi_tmlp':
        return AGSITMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name.startswith('agr_tmlp'):
        return AGRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
            variant_name=model_name,
        )
    if model_name == 'adr_tmlp':
        return ADRTMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
        )
    if model_name.startswith('sga_tmlp_lite'):
        return SGATMLPLite(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
            variant_name=model_name,
        )
    if model_name.startswith('hre_tmlp'):
        return HRETMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset,
            variant_name=model_name,
        )
    if model_name.startswith('moe_tmlp'):
        return MoETMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset)
    if model_name == 'baseline_tmlp':
        return tMLP(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset)
    if model_name == 'ggpl_tmlp_gfg':
        return GGPLTMLPGFG(
            model_config=model_config,
            n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device,
            feat_gate=feat_gate, pruning=pruning, dataset=dataset)
    return MODEL_CARDS[model_name](
        model_config=model_config, 
        n_num_features=n_num, categories=cat_card, n_labels=n_labels, device=device)

def make_optimizer_scheduler(
    model: nn.Module,
    training_config: dict,
):
    """make it at models.py"""
    if not isinstance(model, nn.Module):
        # tree model pass training args in 
        pass

def prepare_hyper_tune_infos(model_name, configs: Union[str, dict], **kwargs):
    """ prepare tune infos """
    assert model_name in MODEL_CARDS, f"unrecognized `{model_name}` model name, choose one of valid models in {MODEL_CARDS}"
    assert all(k in kwargs for k in ['n_num', 'cat_card', 'n_labels']), "provide task-specific params 'n_num', 'cat_card', 'n_labels'"
    if isinstance(configs, str):
        configs = load_config_from_file(configs)
    if model_name == 'ft-transformer':
        kwargs.setdefault('is_large_data', False)
        search_spaces = extract_config(configs, kwargs['is_large_data'])
    else:
        pass
    # some common meta infos
    kwargs.setdefault('save_path', f'tuned_configs/{model_name}')
    search_spaces['meta'] = {'save_path': kwargs['save_path']}
    return model_name, search_spaces

def tune(
    model_name: str = None,
    search_config: Union[dict, str] = None, 
    dataset: Dataset = None,
    batch_size: int = 64,
    patience: int = 8, # a small patience for quick tune
    n_iterations: int = 50,
    framework: HPOLib = 'optuna',
    device: Union[str, torch.device] = 'cuda',
    output_dir: Optional[str] = None,
) -> 'TabModel':
    # assert framework in HPOLib, f"hyper tune only support the following frameworks '{HPOLib}'"

    # device
    device = torch.device(device)

    # task params
    n_num_features = dataset.n_num_features
    categories = dataset.get_category_sizes('train')
    if len(categories) == 0:
        categories = None
    n_labels = dataset.n_classes or 1
    y_std = dataset.y_info.get('std') # for regression
    # preprocess
    datas = DataProcessor.prepare(dataset, device=device)
    # hpo search space
    if isinstance(search_config, str):
        search_spaces = load_config_from_file(search_config)
    else:
        search_spaces = search_config
    search_spaces = extract_config(search_spaces) # for multi-choice spaces
    # meta args
    if output_dir is None:
        now = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        dataset_name = getattr(dataset, 'name', 'dataset')
        output_dir = f"results/{model_name}-{dataset_name}-{now}"
    search_spaces['meta'] = {'save_path': Path(output_dir) / 'tunning'} # save tuning results
    tuned_dir = Path(output_dir) / 'tuned'
    # global variable
    running_time = 0.

    def get_configs(trial: optuna.Trial): # sample configs
        config = {}
        for field in ['model', 'training']:
            config[field] = {}
            for k, space in search_spaces[field].items():
                if space['type'] in ['int', 'float', 'uniform', 'loguniform']:
                    config[field][k] = eval(f"trial.suggest_{space['type']}")(k, low=space['min'], high=space['max'])
                elif space['type'] == 'categorical':
                    config[field][k] = trial.suggest_categorical(k, choices=space['choices'])
                elif space['type'] == 'const':
                    config[field][k] = space['value']
                else:
                    raise TypeError(f"Unsupport suggest type {space['type']} for framework: {framework}")
        config['meta'] = search_spaces['meta']
        config['training'].setdefault('batch_size', batch_size)
        return config
    
    def objective(trial: optuna.Trial):
        configs = get_configs(trial)
        model = make_baseline(
            model_name, configs['model'], 
            n_num=n_num_features, 
            cat_card=categories, 
            n_labels=n_labels, 
            device=device)
        nonlocal running_time
        start = time.time()
        model.fit(
            X_num=datas['train'][0], X_cat=datas['train'][1], ys=datas['train'][2], y_std=y_std,
            eval_set=(datas['val'],),
            patience=patience,
            task=dataset.task_type.value,
            training_args=configs['training'],
            meta_args=configs['meta']) # save best model and configs
        running_time += time.time() - start
        val_metric = (
            model.history['val']['best_metric']
            if dataset.task_type.value != 'regression'
            else -model.history['val']['best_metric']
        )
        return val_metric
    
    def save_per_iter(study: optuna.Study, trail: optuna.Trial):
        # current tuning infos
        tunning_infos = {
            'model_name': model_name,
            'dataset': getattr(dataset, 'name', 'dataset'),
            'cur_trail': trail.number,
            'best_trial': study.best_trial.number,
            'best_val_metric': study.best_value,
            'scores': [t.value for t in study.trials],
            'used_time (s)': running_time,
        }
        with open(Path(search_spaces['meta']['save_path']) / 'tunning.json', 'w') as f:
            json.dump(tunning_infos, f, indent=4)
        # only copy the best tuning result
        if study.best_trial.number == trail.number:
            src_dir = search_spaces['meta']['save_path']
            dst_dir = tuned_dir
            print(f'copy best configs and results: {str(src_dir)} -> {str(dst_dir)}')
            print(f'best val metric: ', np.round(study.best_value, 4))
            if os.path.exists(dst_dir):
                shutil.rmtree(dst_dir)
            shutil.copytree(src_dir, dst_dir)

    study = optuna.create_study(direction='maximize')
    study.optimize(func=objective, n_trials=n_iterations, callbacks=[save_per_iter])

    # load best model
    config_file = Path(tuned_dir) / 'configs.yaml'
    configs = load_config_from_file(config_file)
    model = make_baseline(
        model_name, configs['model'],
        n_num=n_num_features, cat_card=categories, n_labels=n_labels,
        device=device)
    model.load_best_dnn(tuned_dir)
    # prediction
    predictions, results = model.predict(
        X_num=datas['val'][0], X_cat=datas['val'][1], ys=datas['val'][2], y_std=y_std,
        task=dataset.task_type.value,
        return_probs=True, return_metric=True,
        meta_args={'save_path': output_dir})
    print(results)

    return model
